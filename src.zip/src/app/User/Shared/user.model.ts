export class User {
    Id: string;
    Name: string;
    Gender: string;
    DOB: string;
    Avatar: string;
    IsActive: boolean;
}
