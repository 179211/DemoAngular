import { Component, OnInit } from '@angular/core';
import { User } from '../Shared/user.model';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  constructor() { }

  users: User[] = [
    { Id: '1', Name: 'AAA', Gender: 'Male', DOB: '1990/02/02', IsActive: true, Avatar: 'NoImg'},
    { Id: '2', Name: 'BBB', Gender: 'Male', DOB: '1990/02/02', IsActive: false, Avatar: 'NoImg'},
    { Id: '3', Name: 'CCC', Gender: 'Male', DOB: '1990/02/02', IsActive: true, Avatar: 'NoImg'}
  ];

  ngOnInit() {
  }

}
